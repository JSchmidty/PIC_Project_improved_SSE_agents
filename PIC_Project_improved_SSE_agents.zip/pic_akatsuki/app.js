const API = "http://127.0.0.1:5173";
const me = { name: "You" };
let activeDM = null; // null means broadcast

const el = s => document.querySelector(s);
const listEl = el("#messages");
const input = el("#msgInput");
const sendBtn = el("#sendBtn");
const agentList = el("#agentList");

function render(messages){
  listEl.innerHTML = "";
  messages.forEach(m => {
    const li = document.createElement("li");
    li.className = "msg " + (m.from === me.name ? "self" : "");
    const to = m.to && m.to !== "@all" ? ` to ${m.to}` : "";
    li.innerHTML = `<div class="meta"><b>${m.from}</b>${to} • ${new Date(m.created_at).toLocaleTimeString()}</div>
                    <div class="text">${(m.text || "").replaceAll("\n", "<br>")}</div>`;
    listEl.appendChild(li);
  });
  listEl.scrollTop = listEl.scrollHeight;
}

async function fetchMessages(){
  try{
    const res = await fetch(API + "/messages");
    const data = await res.json();
    render(data);
  }catch(e){
    // no-op
  }
}

async function sendMessage(){
  const text = input.value.trim();
  if(!text) return;
  const body = {
    from: me.name,
    to: activeDM || "@all",
    text
  };
  input.value = "";
  await fetch(API + "/send", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(body)});
}

function initSSE(){
  try{
    const es = new EventSource(API + "/stream", { withCredentials: false });
    es.addEventListener("snapshot", e => {
      const data = JSON.parse(e.data);
      render(data);
    });
    es.addEventListener("update", e => {
      const data = JSON.parse(e.data);
      render(data);
    });
    es.onerror = () => {
      // Fallback to polling if SSE drops
      setInterval(fetchMessages, 1500);
    };
  }catch(e){
    setInterval(fetchMessages, 2000);
  }
}

sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keydown", e => {
  if(e.key === "Enter" && !e.shiftKey){ e.preventDefault(); sendMessage(); }
});

agentList.addEventListener("click", e => {
  const li = e.target.closest("li[data-agent]");
  if(!li) return;
  const who = li.getAttribute("data-agent");
  if(activeDM === who){
    activeDM = null;
    li.classList.remove("active");
  }else{
    activeDM = who;
    [...agentList.querySelectorAll("li")].forEach(n => n.classList.remove("active"));
    li.classList.add("active");
  }
});

initSSE();
