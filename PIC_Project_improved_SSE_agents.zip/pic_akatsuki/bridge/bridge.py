from flask import Flask, request, jsonify
from pathlib import Path
from datetime import datetime
import json, os

CHAT_DIR = os.environ.get("PIC_CHAT_DIR", "./chat_data")
Path(CHAT_DIR).mkdir(parents=True, exist_ok=True)
MSG_FILE = Path(CHAT_DIR) / "messages.json"

def read_msgs():
    if MSG_FILE.exists():
        with open(MSG_FILE, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except Exception:
                return []
    return []

def write_msgs(msgs):
    with open(MSG_FILE, "w", encoding="utf-8") as f:
        json.dump(msgs, f, indent=2)

app = Flask(__name__)

@app.get("/messages")
def messages():
    return jsonify(read_msgs())

@app.post("/send")
def send():
    msg = request.get_json(force=True)
    msgs = read_msgs()
    msgs.append(msg)
    write_msgs(msgs)
    return jsonify({"ok": True})

@app.get("/health")
def health():
    return {"ok": True, "count": len(read_msgs())}

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5173, debug=False)
