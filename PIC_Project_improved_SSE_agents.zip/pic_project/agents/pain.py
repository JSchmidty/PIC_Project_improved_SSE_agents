from __future__ import annotations

from typing import List, Dict
from datetime import datetime
from . import signature as _sig  # optional if signature provided in __init__, handled below
from ..utils.message_handler import create_message

NAME = "Pain"
SIGNATURE = "Director of PIC"

def _make_task_sheet(text: str) -> str:
    # Simple deterministic converter for demo
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    return (
        "PIC Task Sheet\n"
        f"Generated: {now}\n"
        "Goal: produce a 15 to 45 second highlight clip that can be monetized.\n"
        "Inputs: user clip summary and any constraints.\n"
        "Steps:\n"
        "  1) Parse the summary and extract: game, character, moment, timestamp hints.\n"
        "  2) Create a beat outline: hook, escalation, payoff, outro CTA.\n"
        "  3) Shot plan (max 8 sec per shot).\n"
        "  4) Caption plan and on screen text.\n"
        "  5) Music and SFX plan.\n"
        "  6) Export specs for TikTok, YT Shorts, Reels.\n"
        "Deliverable: JSON task object for next agents."
    )

def handle_message(msg: Dict) -> List[Dict]:
    text = (msg.get("text") or "").strip()
    responses: List[Dict] = []
    if text.lower().startswith("/status"):
        responses.append(create_message("Pain is online. Send a clip summary to start a task sheet.", sender=NAME, to=msg.get("from"), msg_type="DM", meta={"client": "Agent", "signature": SIGNATURE}))
        return responses
    if "clip summary" in text.lower() or text.lower().startswith("/task"):
        sheet = _make_task_sheet(text)
        responses.append(create_message(sheet, sender=NAME, to=None, msg_type="BROADCAST", meta={"client": "Agent", "signature": SIGNATURE}))
        return responses
    return responses
