from __future__ import annotations
from typing import List, Dict
from ..utils.message_handler import create_message

NAME = "Konan"
SIGNATURE = "Caption Specialist"

HELP = "DM /captions <one line summary> to get a caption plan."

def _caption_plan(summary: str) -> str:
    return (
        "Caption Plan\n"
        f"Summary: {summary}\n"
        "Styles: subtitle, meme, kinetic type.\n"
        "Rules: 32 to 44 chars per line, 2 lines max, contrast safe, avoid blocking HUD.\n"
        "Beats:\n"
        "  Hook: 0 to 2 s, bold claim or punchline.\n"
        "  Escalation: 2 to 8 s, quick verbs and onomatopoeia.\n"
        "  Payoff: 8 to 14 s, reaction or twist.\n"
        "  Outro: last 2 s, CTA short.\n"
        "Deliverables: .srt, on screen text JSON with timecodes."
    )

def handle_message(msg: Dict) -> List[Dict]:
    text = (msg.get("text") or "").strip()
    sender = msg.get("from")
    out: List[Dict] = []
    if text.lower().startswith("/status"):
        out.append(create_message("Konan is online. " + HELP, sender=NAME, to=sender, msg_type="DM", meta={"signature": SIGNATURE}))
        return out
    if text.lower().startswith("/captions"):
        summary = text.split(" ", 1)[1] if " " in text else "general gaming highlight"
        plan = _caption_plan(summary)
        out.append(create_message(plan, sender=NAME, to=None, msg_type="BROADCAST", meta={"signature": SIGNATURE}))
        return out
    # Auto trigger when a PIC Task Sheet appears in broadcast
    if "pic task sheet" in text.lower() and (msg.get("to") in (None, "@all")):
        plan = _caption_plan("derived from Pain sheet")
        out.append(create_message(plan, sender=NAME, to=None, msg_type="BROADCAST", meta={"signature": SIGNATURE}))
    return out
