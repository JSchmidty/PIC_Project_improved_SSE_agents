from __future__ import annotations
from typing import List, Dict
from ..utils.message_handler import create_message

NAME = "Deidara"
SIGNATURE = "Thumbnail Artist"

HELP = "DM /thumb <topic> to get 3 thumbnail prompt options."

def _thumbs(topic: str) -> str:
    return (
        "Thumbnail Prompts\n"
        f"Topic: {topic}\n"
        "1) Extreme close up on key moment, big emoji face, bold 2 word text, high contrast.\n"
        "2) Before vs After split, action blur on the right, clear focus left, thick outline subject cutout.\n"
        "3) POV camera angle with exaggerated perspective, rule of thirds, single dominant color background."
    )

def handle_message(msg: Dict) -> List[Dict]:
    text = (msg.get("text") or "").strip()
    sender = msg.get("from")
    out: List[Dict] = []
    if text.lower().startswith("/status"):
        out.append(create_message("Deidara is online. " + HELP, sender=NAME, to=sender, msg_type="DM", meta={"signature": SIGNATURE}))
        return out
    if text.lower().startswith("/thumb"):
        topic = text.split(" ", 1)[1] if " " in text else "gaming highlight"
        plan = _thumbs(topic)
        out.append(create_message(plan, sender=NAME, to=None, msg_type="BROADCAST", meta={"signature": SIGNATURE}))
        return out
    # Auto trigger on Pain's PIC Task Sheet
    if "pic task sheet" in text.lower() and (msg.get("to") in (None, "@all")):
        plan = _thumbs("derived from Pain sheet")
        out.append(create_message(plan, sender=NAME, to=None, msg_type="BROADCAST", meta={"signature": SIGNATURE}))
    return out
