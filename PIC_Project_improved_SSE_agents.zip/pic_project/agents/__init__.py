from .pain import handle_message as pain_handle
from .konan import handle_message as konan_handle
from .deidara import handle_message as deidara_handle

REGISTRY = {
    "Pain": pain_handle,
    "Konan": konan_handle,
    "Deidara": deidara_handle,
}
