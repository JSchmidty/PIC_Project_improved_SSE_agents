"""
PIC project package initializer.

This package contains the core logic and agent definitions for the Passive Income Clips
(PIC) automation system. See README.md for details on how to run the project and build
a distributable executable.
"""