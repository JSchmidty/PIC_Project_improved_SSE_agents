from __future__ import annotations

from pathlib import Path
from threading import Lock
from typing import List, Dict, Callable, Optional
import os, json, uuid, time

CHAT_DIR = Path(os.environ.get("PIC_CHAT_DIR", Path(__file__).resolve().parents[1] / "chat_data"))
CHAT_DIR.mkdir(parents=True, exist_ok=True)
MSG_FILE = CHAT_DIR / "messages.json"
_LOCK = Lock()

def _load() -> List[Dict]:
    if MSG_FILE.exists():
        try:
            with MSG_FILE.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            return []
    return []

def _save(msgs: List[Dict]) -> None:
    tmp = MSG_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(msgs, f, ensure_ascii=False, indent=2)
    tmp.replace(MSG_FILE)

def read_messages() -> List[Dict]:
    with _LOCK:
        return list(_load())

def write_messages(msgs: List[Dict]) -> None:
    with _LOCK:
        _save(msgs)

def append_message(msg: Dict) -> None:
    with _LOCK:
        msgs = _load()
        msgs.append(msg)
        _save(msgs)

def create_message(text: str, sender: str, to: Optional[str] = None, msg_type: Optional[str] = None, meta: Optional[Dict] = None, task_id: Optional[str] = None) -> Dict:
    mtype = msg_type or ("DM" if to else "BROADCAST")
    return {
        "id": str(uuid.uuid4()),
        "type": mtype,
        "from": sender,
        "to": to or "@all",
        "task_id": task_id,
        "text": text,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "meta": meta or {"client": "Agent"},
    }

def find_messages(filter_fn: Callable[[Dict], bool]) -> List[Dict]:
    return [m for m in read_messages() if filter_fn(m)]

def clear_messages() -> None:
    write_messages([])
