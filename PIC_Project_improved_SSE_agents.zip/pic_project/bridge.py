from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
from pathlib import Path
from threading import Lock, Event, Thread
import os, json, time, uuid, hashlib
from jsonschema import validate, ValidationError

CHAT_DIR = Path(os.environ.get("PIC_CHAT_DIR", Path(__file__).resolve().parent / "chat_data"))
CHAT_DIR.mkdir(parents=True, exist_ok=True)
MSG_FILE = CHAT_DIR / "messages.json"
SCHEMA_FILE = Path(__file__).resolve().parent / "schema" / "message.schema.json"
_LOCK = Lock()

# SSE state
_version = 0
_change_event = Event()

def _hash_messages(msgs):
    # Compact fingerprint to avoid redundant pushes
    h = hashlib.sha256()
    for m in msgs:
        h.update((m.get("id") or "").encode("utf-8"))
        h.update((m.get("created_at") or "").encode("utf-8"))
    return h.hexdigest()

def _load():
    if MSG_FILE.exists():
        try:
            with MSG_FILE.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            return []
    return []

def _save(msgs):
    tmp = MSG_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(msgs, f, ensure_ascii=False, indent=2)
    tmp.replace(MSG_FILE)

def _bump_version():
    global _version
    _version += 1
    _change_event.set()

def _watcher_loop(interval=0.6):
    # Fallback in case appends happen from other processes
    last_fingerprint = ""
    while True:
        time.sleep(interval)
        with _LOCK:
            msgs = _load()
        fp = _hash_messages(msgs)
        if fp != last_fingerprint:
            last_fingerprint = fp
            _bump_version()

def _load_schema():
    try:
        with SCHEMA_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

SCHEMA = _load_schema()

app = Flask(__name__)
CORS(app)

@app.get("/messages")
def messages():
    with _LOCK:
        msgs = _load()
    return jsonify(msgs)

@app.get("/stream")
def stream():
    # Server Sent Events: push on version changes
    def event_gen():
        last_seen = request.headers.get("Last-Event-ID")
        try:
            last_seen = int(last_seen) if last_seen is not None else -1
        except Exception:
            last_seen = -1
        # Always send a snapshot first
        with _LOCK:
            msgs = _load()
        yield f"id: {_version}\n"
        yield "event: snapshot\n"
        payload = json.dumps(msgs, ensure_ascii=False)
        yield f"data: {payload}\n\n"

        current = _version
        while True:
            _change_event.wait(timeout=30)
            _change_event.clear()
            if current != _version:
                current = _version
                with _LOCK:
                    msgs = _load()
                yield f"id: {current}\n"
                yield "event: update\n"
                payload = json.dumps(msgs, ensure_ascii=False)
                yield f"data: {payload}\n\n"
    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no"
    }
    return Response(stream_with_context(event_gen()), headers=headers)

@app.post("/send")
def send():
    data = request.get_json(force=True) or {}
    # Basic normalization
    if "type" not in data:
        data["type"] = "DM" if data.get("to") else "BROADCAST"
    # Schema validation
    if SCHEMA is not None:
        try:
            validate(instance=data, schema=SCHEMA)
        except ValidationError as e:
            return jsonify({"ok": False, "error": "schema_validation_failed", "details": e.message}), 400
    # Fill server fields
    msg = {
        "id": data.get("id") or str(uuid.uuid4()),
        "type": data.get("type"),
        "from": data["from"],
        "to": data.get("to") or "@all",
        "task_id": data.get("task_id"),
        "text": data.get("text", ""),
        "created_at": data.get("created_at") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "meta": data.get("meta") or {"client": "web"},
    }
    with _LOCK:
        msgs = _load()
        msgs.append(msg)
        _save(msgs)
    _bump_version()
    return jsonify({"ok": True, "id": msg["id"]})

@app.get("/health")
def health():
    with _LOCK:
        count = len(_load())
    return jsonify({"ok": True, "count": count, "version": _version})

def run(host="127.0.0.1", port=5173, debug=False):
    t = Thread(target=_watcher_loop, daemon=True)
    t.start()
    app.run(host=host, port=port, debug=debug, threaded=True)

if __name__ == "__main__":
    run()
