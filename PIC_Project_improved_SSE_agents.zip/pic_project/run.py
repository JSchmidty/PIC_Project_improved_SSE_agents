import threading
import time
import importlib
from pathlib import Path
from typing import Dict, List

from .bridge import run as run_bridge
from .utils.message_handler import read_messages, append_message
from .agents import REGISTRY

BRIDGE_PORT = 5173

def start_bridge_thread():
    t = threading.Thread(target=lambda: run_bridge(host="127.0.0.1", port=BRIDGE_PORT, debug=False), daemon=True)
    t.start()
    return t

def route_targets(msg: Dict) -> List[str]:
    # If DM to an agent by name, return that. Otherwise broadcast to all registered agents.
    target = (msg.get("to") or "").strip()
    if target and target != "@all" and target in REGISTRY:
        return [target]
    return list(REGISTRY.keys())

def dispatch_loop(poll=1.0):
    last_seen = 0
    print("Dispatcher running. Ctrl+C to stop.")
    while True:
        try:
            msgs = read_messages()
            if len(msgs) > last_seen:
                new = msgs[last_seen:]
                last_seen = len(msgs)
                for m in new:
                    # skip agent messages to avoid loops
                    sender = (m.get("from") or "").lower()
                    if sender in {name.lower() for name in REGISTRY.keys()}:
                        continue
                    # deliver to targets
                    for agent_name in route_targets(m):
                        handler = REGISTRY.get(agent_name)
                        if not handler:
                            continue
                        try:
                            replies = handler(m) or []
                        except Exception as e:
                            replies = []
                            print(f"[error] agent {agent_name} failed: {e}")
                        for r in replies:
                            append_message(r)
            time.sleep(poll)
        except KeyboardInterrupt:
            print("Dispatcher stopped.")
            break

def main():
    start_bridge_thread()
    dispatch_loop(poll=0.5)

if __name__ == "__main__":
    main()
