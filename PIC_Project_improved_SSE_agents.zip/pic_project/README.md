# Passive Income Clips (PIC) Akatsuki Agents

This repository contains a working prototype of the PIC Akatsuki agent system
as described in the master reference. The goal of this project is to
demonstrate how Elden Ring gameplay clips can be processed through a series
of AI‑inspired agents, each with a unique persona. The agents communicate
via a shared chat log that is surfaced through an iMessage‑style web UI.

## Features

* **Bridge server**: A lightweight Flask application (`pic_project/bridge.py`) that
  exposes `/messages` and `/send` endpoints. The web client polls these to
  display conversation history and post new messages.
* **Agent dispatcher**: A dispatcher loop (`pic_project/run.py`) that watches
  the chat log for new messages and routes them to the appropriate agent
  handler. Responses from agents are appended back to the log.
* **Pain agent**: A stub implementation of the Director that listens for
  `clip_summary:` directives and emits a dummy PIC task sheet. Additional
  agents can be added by placing modules in the `pic_project/agents`
  directory and defining a `handle_message` function.
* **Chat UI starter**: The `index.html`, `styles.css`, and `app.js` files
  under `pic_akatsuki/` render a conversation using an iPhone‑style
  interface. The UI polls the bridge server and posts messages to it.

## Running the Project

1. **Install dependencies**: This prototype has no hard dependency on
   external libraries. If the Flask package is available, the bridge
   server will use it; otherwise it will fall back to Python's built‑in
   `http.server`. Installing Flask is optional but recommended for a
   smoother development experience:

   ```bash
   pip install flask
   ```

2. **Start the chat UI bridge**: Launch the dispatcher and bridge server.

   ```bash
   python -m pic_project.run
   ```

   The bridge will listen on `http://127.0.0.1:5173`. The dispatcher loop
   begins polling the message log immediately.

3. **Open the UI**: Open `pic_akatsuki/index.html` in your browser. The
   page will load past messages and allow you to send new ones. Try typing
   `@Pain clip_summary: Malenia one flask punish` to see Pain generate a
   dummy task sheet.

4. **Interact**: Use `@AgentName` to DM a specific agent or `@all` to
   broadcast. Slash commands like `/status` can be sent to Pain.

## Packaging into an Executable

To redistribute this application as a Windows `.exe`, you can use
PyInstaller. First, ensure that all Python files are self‑contained
and that any data files (HTML, CSS, JS, JSON) are included. Then run:

```bash
pip install pyinstaller
pyinstaller --onefile -n pic_akatsuki.exe -p pic_project run.py
```

This command builds a single executable that contains the dispatcher,
bridge server, and all referenced modules. You may need to tweak the
PyInstaller spec file to include static assets; see the PyInstaller
documentation for details.

After building, upload the resulting executable (located in the `dist/`
directory) to your GitHub releases page. End users can download and run
it directly on Windows 11 without installing Python. They will still
need to unzip the chat UI files and double‑click `index.html` to open
the interface.

## Extending the Agents

Each agent lives in its own module under `pic_project/agents/`. To
implement a new agent:

1. Create a Python module with a name derived from the agent (e.g.
   `kisame.py`).
2. Define a `NAME` and `SIGNATURE` constant and a `handle_message(msg)`
   function. The function should inspect the incoming message and return
   a list of messages to send.
3. Add the agent's name to the target list in `pic_project/run.py`.

Agents can use the helper functions in `pic_project/utils/message_handler.py`
to build and append messages. For full integration with the PIC
master reference, you would connect these handlers to AI services
like ChatGPT, Suno, and Hedra. In this demo environment, they return
stub data.

## Development Notes

* The chat data directory defaults to `./chat_data` relative to where you
  run the script. Set the environment variable `PIC_CHAT_DIR` to
  override this.
* The dispatcher runs in a simple polling loop. For a production
  implementation you may want to incorporate more robust event handling
  or concurrency management.
* Only the Pain agent is fleshed out. Other agents are placeholders.
* The current date and time zone are not enforced in code but can be
  incorporated into future versions for scheduling and analytics.

## Logging

While running, the dispatcher prints basic status to the console.
You can augment this by adding more sophisticated logging (e.g.
using Python's `logging` module) to record each agent invocation and
decision. For brevity, this prototype does not include a comprehensive
log system.

## Licence

This code is provided as a demonstration prototype and is released
under the MIT licence. See `LICENSE` for details.